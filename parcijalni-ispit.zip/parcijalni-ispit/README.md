# parcijalni-ispit
To start the project:
   - run `node app.js` in your terminal
   - go to `localhost:3000`
